package com.officer;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/UpdateParcelStatusServlet")
public class DeliveryStatus extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String bookingId = request.getParameter("bookingId");
        String newStatus = request.getParameter("newStatus");
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Load Derby driver and connect
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
            conn = DriverManager.getConnection("jdbc:derby:/home/venkypedia/DataDB");

            String sql = "UPDATE ParcelDetails SET parcel_status = ?, updated_at = CURRENT_TIMESTAMP WHERE booking_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, newStatus);
            pstmt.setString(2, bookingId);

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                response.sendRedirect("updateStatus.jsp?message=Status updated to '" + newStatus + "' successfully&type=success");
                System.out.println("sucess");
            } else {
                response.sendRedirect("updateStatus.jsp?message=Invalid Booking ID or update failed&type=error");
                System.out.println("failed");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("updateStatus.jsp?message=An error occurred: " + e.getMessage() + "&type=error");
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
    }
}
