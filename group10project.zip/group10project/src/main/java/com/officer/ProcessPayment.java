package com.officer;

import java.io.*;
import java.sql.*;
import java.util.UUID;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ProcessPaymentServlet")
public class ProcessPayment extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String bookingId = request.getParameter("bookingId");
        String cardNumber = request.getParameter("cardNumber");
        String expiry = request.getParameter("expiry");
        String cvv = request.getParameter("cvv");
        String cardholder = request.getParameter("cardholder");
        String amountStr = request.getParameter("amount");
        double amount = Double.parseDouble(amountStr);

        String paymentId = "PAY-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        String transactionId = "TXN-" + UUID.randomUUID().toString().substring(0, 10).toUpperCase();
        String transactionType = "Debit";
        String status = "Success";
        String last4 = cardNumber.substring(cardNumber.length() - 4);

        Timestamp now = new Timestamp(System.currentTimeMillis());

        Connection conn = null;
        PreparedStatement ps = null;

        try {
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
            conn = DriverManager.getConnection("jdbc:derby:/home/venkypedia/DataDB");

            conn.setAutoCommit(false); 

            String insertSQL = """
                INSERT INTO payments (
                    payment_id, transaction_id, booking_id,
                    transaction_date, transaction_type,
                    card_number_last4, cardholder_name,
                    transaction_amount, transaction_status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """;

            ps = conn.prepareStatement(insertSQL);
            ps.setString(1, paymentId);
            ps.setString(2, transactionId);
            ps.setString(3, bookingId);
            ps.setTimestamp(4, now);
            ps.setString(5, transactionType);
            ps.setString(6, last4);
            ps.setString(7, cardholder);
            ps.setDouble(8, amount);
            ps.setString(9, status);

            int rowsInserted = ps.executeUpdate();
            ps.close();

            // Update ParcelDetails with payment status and time
            String updateParcel = """
                UPDATE ParcelDetails
                SET payment_status = ?, parcel_payment_time = ?, booking_status = ?, parcel_status = ?, updated_at = ?
                WHERE booking_id = ?
            """;

            ps = conn.prepareStatement(updateParcel);
            ps.setString(1, "Paid");
            ps.setTimestamp(2, now);
            ps.setString(3, "Booked");
            ps.setString(4, "In Transit");          
            ps.setTimestamp(5, now);
            ps.setString(6, bookingId);

            int rowsUpdated = ps.executeUpdate();

            if (rowsInserted > 0 && rowsUpdated > 0) {
                conn.commit(); 
                request.setAttribute("paymentId", paymentId);
                request.setAttribute("transactionId", transactionId);
                request.setAttribute("transactionDate", now.toString());
                request.setAttribute("transactionType", transactionType);
                request.setAttribute("bookingId", bookingId);
                request.setAttribute("amount", amount);
                request.setAttribute("transactionStatus", status);

                RequestDispatcher rd = request.getRequestDispatcher("paymentSuccess.jsp");
                rd.forward(request, response);
            } else {
                conn.rollback(); 
                response.getWriter().println("Payment failed during update.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            if (conn != null) {
                try { conn.rollback(); } catch (SQLException ignored) {}
            }
            response.getWriter().println("Internal Error: " + e.getMessage());
        } finally {
            try { if (ps != null) ps.close(); } catch (Exception ignored) {}
            try { if (conn != null) conn.close(); } catch (Exception ignored) {}
        }
    }
}
