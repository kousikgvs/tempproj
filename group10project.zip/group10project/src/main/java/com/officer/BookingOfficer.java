package com.officer;

import java.util.UUID;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ParcelBookingServlet")
public class BookingOfficer extends HttpServlet {

    private static final double BASE_RATE = 50;
    private static final double COST_PER_GRAM = 0.02;
    private static final double TAX_RATE = 0.05;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession();
        String officerId = (String) session.getAttribute("officerId");

        if (officerId == null) {
            officerId = "officer123"; 
        }

        String customerId = request.getParameter("CustomerID");
        String receiverName = request.getParameter("receiverName");
        String receiverAddress = request.getParameter("receiverAddress");
        String deliveryType = request.getParameter("deliveryType");
        String packing = request.getParameter("packing");

        int receiverPin, parcelWeight;
        long receiverMobile;

        try {
            receiverPin = Integer.parseInt(request.getParameter("receiverPin"));
            receiverMobile = Long.parseLong(request.getParameter("receiverMobile"));
            parcelWeight = Integer.parseInt(request.getParameter("parcelWeight"));
        } catch (NumberFormatException e) {
            out.println("Invalid numeric inputs.");
            return;
        }

        int deliveryCharge = switch (deliveryType) {
            case "express" -> 80;
            case "sameDay" -> 150;
            default -> 30;
        };

        int packingCharge = packing.equals("premium") ? 30 : 10;
        double weightCharge = parcelWeight * COST_PER_GRAM;

        double serviceCost = (BASE_RATE + weightCharge + deliveryCharge + packingCharge) * (1 + TAX_RATE);
        int finalServiceCost = (int) Math.round(serviceCost);
        Timestamp currentTime = new Timestamp(System.currentTimeMillis());

        try {
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
            Connection conn = DriverManager.getConnection("jdbc:derby:/home/venkypedia/DataDB;create=true");

           
            PreparedStatement checkCustomer = conn.prepareStatement("SELECT customer_id FROM Customer WHERE customer_id = ?");
            checkCustomer.setString(1, customerId);
            ResultSet rsCustomer = checkCustomer.executeQuery();
            if (!rsCustomer.next()) {
                out.println("Error: Customer ID does not exist.");
                return;
            }

            
            PreparedStatement checkOfficer = conn.prepareStatement("SELECT officer_id FROM Officer WHERE officer_id = ?");
            checkOfficer.setString(1, officerId);
            ResultSet rsOfficer = checkOfficer.executeQuery();
            if (!rsOfficer.next()) {
                out.println("Error: Officer ID does not exist.");
                return;
            }

            String bookingID = "BOOK-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
            String sql = """
                INSERT INTO ParcelDetails (
                    customer_id, officer_id, booking_id, 
                    receiver_name, receiver_address, receiver_pin, receiver_mobile, 
                    parcel_weight_in_gram, parcel_contents_description, parcel_delivery_type, 
                    parcel_packing_preference, parcel_pickup_time, parcel_dropoff_time, 
                    parcel_service_cost, parcel_payment_time
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """;

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, customerId);
            ps.setString(2, officerId);
            ps.setString(3, bookingID);
            ps.setString(4, receiverName);
            ps.setString(5, receiverAddress);
            ps.setInt(6, receiverPin);
            ps.setLong(7, receiverMobile);
            ps.setInt(8, parcelWeight);
            ps.setString(9, "N/A");
            ps.setString(10, deliveryType);
            ps.setString(11, packing);
            ps.setTimestamp(12, currentTime);
            ps.setTimestamp(13, currentTime);
            ps.setInt(14, finalServiceCost);
            ps.setTimestamp(15, currentTime);

            int inserted = ps.executeUpdate();
            if (inserted > 0) {
                request.setAttribute("bookingId", bookingID);
                request.setAttribute("serviceCost", finalServiceCost);
                request.setAttribute("CustomerID", customerId);
                
                RequestDispatcher rd = request.getRequestDispatcher("payment.jsp");
                rd.forward(request, response);
            } else {
                out.println("Booking failed. Please try again.");
            }

            ps.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
            out.println("Internal error: " + e.getMessage());
        }
    }
}