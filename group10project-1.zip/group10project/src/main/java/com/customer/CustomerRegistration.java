package com.customer;

import java.io.IOException;
import java.security.MessageDigest;
import java.sql.*;
import java.util.UUID;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/CustomerRegistrationServlet")
public class CustomerRegistration extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String countryCode = request.getParameter("countryCode");
        String mobile = request.getParameter("mobile");
        String address = request.getParameter("address");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");
        String preferences = request.getParameter("preferences");

        if (!password.equals(confirmPassword)) {
            request.setAttribute("errorMessage", "❌ Passwords do not match!");
            request.getRequestDispatcher("CustomerSignup.jsp").forward(request, response);
            return;
        }

        Connection con = null;
        PreparedStatement ps = null;

        try {
            String encryptedPassword = encryptPassword(password);
            String customerId = "CUST" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

            Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
            con = DriverManager.getConnection("jdbc:derby:D:/Users/2782073/DataDB;create=true");
            String insertSQL = """
                INSERT INTO CUSTOMER (CUSTOMER_ID, NAME, EMAIL, MOBILE, ADDRESS, PASSWORD, PREFERENCES)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """;
            ps = con.prepareStatement(insertSQL);
            ps.setString(1, customerId);
            ps.setString(2, name);
            ps.setString(3, email);
            ps.setString(4, countryCode + mobile);
            ps.setString(5, address);
            ps.setString(6, encryptedPassword);
            ps.setString(7, preferences);

            int status = ps.executeUpdate();

            if (status > 0) {
                request.setAttribute("customerId", customerId);
                request.setAttribute("name", name);
                request.setAttribute("email", email);
                request.setAttribute("success", "✅ Customer registration successful.");
                request.getRequestDispatcher("RegistrationAcknowledgment.jsp").forward(request, response);
            } else {
                request.setAttribute("errorMessage", "❌ Registration failed. Please try again.");
                request.getRequestDispatcher("CustomerSignup.jsp").forward(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "⚠️ Error: " + e.getMessage());
            request.getRequestDispatcher("CustomerSignup.jsp").forward(request, response);
        } finally {
            try { if (ps != null) ps.close(); } catch (Exception ignored) {}
            try { if (con != null) con.close(); } catch (Exception ignored) {}
        }
    }

    private String encryptPassword(String password) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hash = md.digest(password.getBytes("UTF-8"));
        StringBuilder sb = new StringBuilder();
        for (byte b : hash) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}
