package com.customer;
import java.io.*;
import java.security.MessageDigest;
import java.sql.*;
import java.util.UUID;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/CustomerLoginServlet")
public class CustomerSignin extends HttpServlet{
	 protected void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
		 	System.out.print("Started man");
	        String customerId = request.getParameter("customerId");
	        String password = request.getParameter("password");

	        Connection con = null;
	        PreparedStatement ps = null;

	        try {
	        	
	            String encryptedPassword = encryptPassword(password);

	            Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
	            con = DriverManager.getConnection("jdbc:derby:/home/venkypedia/DataDB;create=true");

	            // Insert customer data
	            String insertSQL = "SELECT * FROM CUSTOMERS where CUSTOMER_ID = ?";
	            ps = con.prepareStatement(insertSQL);
	            ps.setString(1, customerId);

	            ResultSet resultSet = ps.executeQuery();
	            
	            String OriginalencryptedPassword = "";
	            
	            while (resultSet.next()) {
	                String id = resultSet.getString("CUSTOMER_Id");
	                String password_ = resultSet.getString("password");
	            	if(id.equals(customerId)) {
	            		OriginalencryptedPassword = password_;
	            	}
	            }
	            
	            if(encryptedPassword.equals(OriginalencryptedPassword)) {
	            	request.setAttribute("success", "Customer Registration successful.");
	            	request.setAttribute("role", "Customer");
	            	request.setAttribute("customerID", customerId);
	                RequestDispatcher rd = request.getRequestDispatcher("LoginAcknowledgment.jsp");
	                rd.forward(request, response);
	                PrintWriter out = response.getWriter();
	                System.out.print("Done man");
	                out.println("Done Man");
	            }

	        } catch (Exception e) {
	            e.printStackTrace();
	            request.setAttribute("errorMessage", "An error occurred: " + e.getMessage());
	            RequestDispatcher rd = request.getRequestDispatcher("LoginAcknowledgment.jsp");
	            rd.forward(request, response);
	        } finally {
	            try {
	                if (ps != null) ps.close();
	                if (con != null) con.close();
	            } catch (Exception ex) {
	                ex.printStackTrace();
	            }
	        }
	    }

	    private String encryptPassword(String password) throws Exception {
	        MessageDigest md = MessageDigest.getInstance("SHA-256");
	        byte[] hash = md.digest(password.getBytes("UTF-8"));
	        StringBuilder sb = new StringBuilder();
	        for (byte b : hash) sb.append(String.format("%02x", b));
	        return sb.toString();
	    }
}
