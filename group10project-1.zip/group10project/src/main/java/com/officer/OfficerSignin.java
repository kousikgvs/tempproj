package com.officer;

import java.io.*;
import java.security.MessageDigest;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/OfficerLoginServlet")
public class OfficerSignin extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("Started man");
        String officerId = request.getParameter("officerId");
        String password = request.getParameter("password");

        Connection con = null;
        PreparedStatement ps = null;
        Statement stmt = null;

        try {
            String encryptedPassword = encryptPassword(password);

            Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
            con = DriverManager.getConnection("jdbc:derby:/home/venkypedia/DataDB;create=true");

            stmt = con.createStatement();

//            String sampleEncryptedPwd = encryptPassword("123");
            String sampleEncryptedPwd = ("123");

            String query = "SELECT * FROM Officer WHERE officer_id = ?";
            ps = con.prepareStatement(query);
            ps.setString(1, officerId);
            ResultSet rs = ps.executeQuery();

            String dbPassword = null;
            if (rs.next()) {
                dbPassword = rs.getString("password");
            }

            if (dbPassword != null && dbPassword.equals(password)) {
                request.setAttribute("success", "Officer Login successful.");
                request.setAttribute("officerID", officerId);
                request.setAttribute("role", "Officer");
                HttpSession session = request.getSession();
                session.setAttribute("officerId" , officerId);
                RequestDispatcher rd = request.getRequestDispatcher("LoginAcknowledgement.jsp");
                rd.forward(request, response);
            } else {
                request.setAttribute("errorMessage", "Invalid credentials.");
                System.out.println();
                RequestDispatcher rd = request.getRequestDispatcher("LoginAcknowledgement.jsp");
                rd.forward(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "An error occurred: " + e.getMessage());
            System.out.println(e.getMessage());
            RequestDispatcher rd = request.getRequestDispatcher("LoginAcknowledgement.jsp");
            rd.forward(request, response);
        } finally {
            try {
                if (ps != null) ps.close();
                if (stmt != null) stmt.close();
                if (con != null) con.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    private String encryptPassword(String password) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hash = md.digest(password.getBytes("UTF-8"));
        StringBuilder sb = new StringBuilder();
        for (byte b : hash)
            sb.append(String.format("%02x", b));
        return sb.toString();
    }
}