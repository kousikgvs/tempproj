package com.officer;

import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ViewParcelDetailsServlet")
public class ViewBooking extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Map<String, String>> bookings = new ArrayList<>();
        String filterCustId = request.getParameter("filterCustId");
        String filterBookingId = request.getParameter("filterBookingId");

        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
            con = DriverManager.getConnection("jdbc:derby:/home/venkypedia/DataDB;create=true");

            StringBuilder query = new StringBuilder("SELECT * FROM ParcelDetails");
            if (filterCustId != null && !filterCustId.trim().isEmpty()) {
                query.append(" AND customer_id = ?");
            }
            if (filterBookingId != null && !filterBookingId.trim().isEmpty()) {
                query.append(" AND booking_id = ?");
            }

            pst = con.prepareStatement(query.toString());
            int index = 1;
            if (filterCustId != null && !filterCustId.trim().isEmpty()) {
                pst.setString(index++, filterCustId.trim());
            }
            if (filterBookingId != null && !filterBookingId.trim().isEmpty()) {
                pst.setString(index++, filterBookingId.trim());
            }

            rs = pst.executeQuery();
            while (rs.next()) {
                Map<String, String> booking = new HashMap<>();
                booking.put("bookingId", rs.getString("booking_id"));
                booking.put("customerId", rs.getString("customer_id"));
                booking.put("officerId", rs.getString("officer_id"));
                booking.put("receiverName", rs.getString("receiver_name"));
                booking.put("receiverAddress", rs.getString("receiver_address"));
                booking.put("cost", "₹" + rs.getInt("parcel_service_cost"));
                booking.put("status", rs.getString("booking_status"));
                booking.put("bookingDate", rs.getTimestamp("created_at").toString().split(" ")[0]);
                bookings.add(booking);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (pst != null) pst.close(); } catch (Exception e) {}
            try { if (con != null) con.close(); } catch (Exception e) {}
        }

        request.setAttribute("bookings", bookings);
        request.getRequestDispatcher("viewBooking.jsp").forward(request, response);
    }
}
