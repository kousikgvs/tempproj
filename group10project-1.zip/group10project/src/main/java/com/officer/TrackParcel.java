package com.officer;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

@WebServlet("/TrackParcelServlet")
public class TrackParcel extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String bookingId = request.getParameter("bookingId");
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
            conn = DriverManager.getConnection("jdbc:derby:/home/venkypedia/DataDB");

            String query =
                    "SELECT p.booking_id, c.customer_name, c.address, " +
                    "p.receiver_name, p.receiver_address, " +
                    "p.created_at, p.parcel_status " +
                    "FROM ParcelDetails p " +
                    "JOIN Customer c ON p.customer_id = c.customer_id " +
                    "WHERE p.booking_id = ?";

            ps = conn.prepareStatement(query);
            ps.setString(1, bookingId);
            rs = ps.executeQuery();

            out.println("<html><head><title>Parcel Tracking</title>");
            out.println("<style>");
            out.println("body { font-family: Arial; background-color: #f9f9f9; padding: 20px; }");
            out.println("table { border-collapse: collapse; width: 100%; margin-top: 20px; }");
            out.println("th, td { border: 1px solid #ccc; padding: 10px; text-align: left; }");
            out.println("th { background-color: #f2f2f2; }");
            out.println("</style></head><body>");
            out.println("<h1>📦 Parcel Tracking Details</h1>");

            if (rs.next()) {
                out.println("<table>");
                out.println("<tr><th>Booking ID</th><th>Full Name</th><th>Address</th>");
                out.println("<th>Receiver Name</th><th>Receiver Address</th>");
                out.println("<th>Date of Booking</th><th>Parcel Status</th></tr>");

                out.println("<tr>");
                out.println("<td>" + rs.getString("booking_id") + "</td>");
                out.println("<td>" + rs.getString("customer_name") + "</td>");
                out.println("<td>" + rs.getString("address") + "</td>");
                out.println("<td>" + rs.getString("receiver_name") + "</td>");
                out.println("<td>" + rs.getString("receiver_address") + "</td>");
                out.println("<td>" + rs.getTimestamp("created_at") + "</td>");
                out.println("<td>" + rs.getString("parcel_status") + "</td>");
                out.println("</tr>");
                out.println("</table>");
            } else {
                out.println("<p style='color:red;'>❌ No parcel found with Booking ID: " + bookingId + "</p>");
            }

            out.println("</body></html>");

        } catch (Exception e) {
            out.println("<p style='color:red;'>Error: " + e.getMessage() + "</p>");
            e.printStackTrace();
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception ignored) {}
            try { if (ps != null) ps.close(); } catch (Exception ignored) {}
            try { if (conn != null) conn.close(); } catch (Exception ignored) {}
        }
    }
}
