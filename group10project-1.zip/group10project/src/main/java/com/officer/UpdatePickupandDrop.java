package com.officer;

import java.io.*; 
import java.sql.*; 
import javax.servlet.*; 
import javax.servlet.annotation.WebServlet; 
import javax.servlet.http.*;

@WebServlet("/UpdateScheduleServlet") 

public class UpdatePickupandDrop extends HttpServlet 
{ 
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

String bookingId = request.getParameter("bookingId");
    String pickupTime = request.getParameter("pickupTime");
    String dropoffTime = request.getParameter("dropoffTime");

    Connection con = null;
    PreparedStatement pst = null;

    try {
        Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
        con = DriverManager.getConnection("jdbc:derby:D:\\Users\\2782073\\DataDB;create=true");

        String sql = "UPDATE ParcelDetails SET parcel_pickup_time = ?, parcel_dropoff_time = ?, updated_at = CURRENT_TIMESTAMP WHERE booking_id = ?";
        pst = con.prepareStatement(sql);
        pst.setString(1, pickupTime);
        pst.setString(2, dropoffTime);
        pst.setString(3, bookingId);

        int rows = pst.executeUpdate();

        if (rows > 0) {
            response.sendRedirect("UpdatePickup.jsp?message=Pickup%20and%20Dropoff%20Updated%20Successfully&type=success");
        } else {
            response.sendRedirect("UpdatePickup.jsp?message=Invalid%20Booking%20ID&type=error");
        } 

    } catch (Exception e) {
        e.printStackTrace();
        response.sendRedirect("pickupSchedule.jsp?message=Error:%20" + e.getMessage() + "&type=error");
    } finally {
        try { if (pst != null) pst.close(); } catch (SQLException e) {}
        try { if (con != null) con.close(); } catch (SQLException e) {}
    }
}

}