package com.officer;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/LogoutServlet")
public class Logout extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false); // get current session
        if (session != null) {
            session.removeAttribute("officerId");  // Remove specific attribute
            session.invalidate();                 // Or invalidate entire session
        }

        response.sendRedirect("officerLogin.jsp"); // redirect to login
    }
}
