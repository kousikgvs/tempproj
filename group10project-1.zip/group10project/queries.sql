drop table ParcelDetails;
drop table Officer;
drop table Customer;


CREATE TABLE Customer (
    customer_id VARCHAR(20),
    customer_name varchar(255),
    email varchar(255),
    mobile_number BIGINT,
  	address varchar(255),
  	password varchar(255),
  	PRIMARY KEY (customer_id)
);


CREATE TABLE officer (
    officer_id VARCHAR(20) PRIMARY KEY,
    officer_name VARCHAR(255),
    email VARCHAR(255),
    mobile_number BIGINT,
    address VARCHAR(255),
    password VARCHAR(255)
);


CREATE TABLE ParcelDetails (
    booking_id VARCHAR(20) PRIMARY KEY,
    
    customer_id VARCHAR(20) NOT NULL,
    officer_id VARCHAR(20) NOT NULL,
    
    receiver_name VARCHAR(100) NOT NULL,
    receiver_address VARCHAR(100) NOT NULL,
    receiver_pin INT NOT NULL,
    receiver_mobile BIGINT NOT NULL,
    
    parcel_weight_in_gram INT NOT NULL,
    parcel_contents_description VARCHAR(200),
    parcel_delivery_type VARCHAR(50),
    parcel_packing_preference VARCHAR(50),
    parcel_pickup_time VARCHAR(50),
    parcel_dropoff_time VARCHAR(50),
    
    parcel_service_cost INT,
    
    booking_status VARCHAR(20) DEFAULT 'Processing', 
    payment_status VARCHAR(20) DEFAULT 'Pending', 
    parcel_status  VARCHAR(20) DEFAULT 'New',
    
    parcel_payment_time TIMESTAMP,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id) ON DELETE CASCADE,
    FOREIGN KEY (officer_id) REFERENCES Officer(officer_id) ON DELETE CASCADE
);

CREATE TABLE payments (
	
	payment_id VARCHAR(50) PRIMARY KEY,
	transaction_id VARCHAR(50),
	booking_id VARCHAR(20),
	transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	transaction_type VARCHAR(10),
	card_number_last4 CHAR(4),
	cardholder_name VARCHAR(100),
	transaction_amount DECIMAL(10,2),
	transaction_status VARCHAR(20),
	FOREIGN KEY (booking_id) REFERENCES ParcelDetails(booking_id) ON DELETE CASCADE
	
);

select * from Customer;
select * from ParcelDetails;

INSERT INTO Officer VALUES ('officer123', 'Officer Ravi', 'officer@example.com', 9876543210, 'Pune, Maharashtra', '123');

INSERT INTO Customer (
    customer_id,
    customer_name,
    email,
    mobile_number,
    address,
    password
) VALUES (
    'CUST1',
    'John Doe',
    'john.doe@example.com',
    9876543210,
    '123 Main Street, Cityville',
    'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3'
);

select * from ParcelDetails;

SELECT pd.booking_id, c.customer_name, c.address,
                       pd.receiver_name, pd.receiver_address,
                       pd.created_at, pd.parcel_status
                FROM ParcelDetails pd
                JOIN Customer c ON pd.customer_id = c.customer_id
                WHERE pd.booking_id = 'BOOK-1F383BDB';
